# Unreleased source and acceptance

The working source identifies itself as **0.4.4**. It uses CLI protocol **2**,
database schema **12**, and bus/message/event versions **1**. It has not been
published as a release by this implementation work. The default remote installer
selects its configured release ref; it does not install an unpublished working tree.

Current behavior is documented in the [skill](../skills/agents-collaboration/SKILL.md),
[implementation guide](resilient-workforce.md) and [migration guide](legacy-migration.md).
Fresh claims receive contracts, engine launches are supervised, message delivery
requires bus receipts, and new merges require configured executable gates.

## Recorded validation

The [latest recorded broad runtime snapshot](validation/legacy-cleanup/report.md) has:

- 379 passing Linux Python 3.13 cases from one complete discovery;
- 46 passing focused Windows Python 3.11 checks and two POSIX-only skips;
- unchanged inputs within both runs and matching normalized source fingerprints;
- retained failed development runs, logs, per-case outcomes and input hashes.

Its engine SHA-256 is
`d819647a59aa9415257f2d4384d5bb4f87a42b35b149ea6960cb87229e298a22`.
This is evidence for that source. Later edits, including the browser dashboard
preview and documentation alignment, are outside that runtime snapshot. Older
schema-10/11/12 reports remain historical; their case counts cannot be added to
claim a complete current-source pass.

## Acceptance still needed

- Execute the full Windows/Linux/macOS matrix against the candidate being
  published. Hosted configuration is not an executed result.
- Finish the proposal's transition/branch audit beyond selected crash windows.
- Validate native adapters on actual installed/authenticated CLIs where claimed;
  recorded help compatibility does not establish successful live work.
- Validate the newly included browser dashboard from a real source installation
  and the required platforms. Its manifest inclusion is separate from acceptance.
- Keep unmeasured usage unknown and preserve benchmark failures. Real-team
  productivity, authenticated billing and comprehensive external-call metering
  remain unestablished.
- Review the [conformance mapping](workforce-conformance.md) before declaring the
  original proposal complete. Distributed identity and OS sandboxing remain out
  of scope for this local implementation.

## Reproduce and publish

Use a disposable checkout/repository and a fresh evidence directory:

```text
python -m ruff check .
python scripts/make_manifest.py --check
python scripts/validate_candidate.py --workers 2 --output PATH_TO_NEW_EVIDENCE_DIRECTORY
```

For a local-source installation, replace both paths with reviewed source and
an existing target repository:

```text
python install.py --source PATH_TO_SOURCE --project PATH_TO_PROJECT --all
```

Keep source unchanged during validation and report each result's actual scope.
The [platform guide](platform-validation.md) describes the six-report CI gate.
Publication follows [CONTRIBUTING.md](../CONTRIBUTING.md): settle required checks,
prepare the version/ref and manifest, then publish through the authorized release
workflow. No release or hosted pass follows from these local records alone.
