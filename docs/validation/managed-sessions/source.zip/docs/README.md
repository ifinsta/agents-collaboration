# Documentation

Current source: **0.4.4, unreleased**; CLI protocol **2**, database schema **12**,
bus/message/event versions **1**. Use the installed skill for an older release.
The [migration guide](legacy-migration.md) describes the breaking cleanup.

## Start here

| Need | Document |
|---|---|
| Purpose, installation and workflow overview | [Repository README](../README.md) |
| Select a release or install local source | [Installation](../INSTALL.md) |
| Agent instructions and command reference | [Installed skill](../skills/agents-collaboration/SKILL.md) |
| Concrete collaboration workflows | [Use cases](../usecases/README.md) |
| Local trust boundary and sensitive data | [Security policy](../SECURITY.md) |
| Architecture, enforcement and limits | [Design](design.md) |

## Contracts and operation

| Topic | Document |
|---|---|
| Goals, architecture, assignments, review and memory | [Workforce implementation](resilient-workforce.md) |
| Message envelopes, leases, acknowledgements and hooks | [Bus contract](../skills/agents-collaboration/BUS.md), [JSON Schema](../skills/agents-collaboration/BUS.schema.json) |
| Owned processes, stop policy and uncertain recovery | [Process supervision](process-supervision.md) |
| One terminal, headless workers and retained audit tabs | [Managed sessions](managed-sessions.md) |
| Integration, outcome checks and receipts | [Completion evidence](completion-evidence.md) |
| Recorded time, tokens/cost and missing accounting | [Usage allowances](usage-budgets.md) |
| Browser dashboard, access token and observation mode | [Web dashboard](web-dashboard.md) |
| Adapter command snapshots and readiness checks | [Agent CLIs](agents.md) |
| Implemented behavior and known gaps | [Edge-case register](../skills/agents-collaboration/EDGE-CASES.md) |

## Evidence and release readiness

The latest recorded broad runtime snapshot passed **379 Linux tests** and **46 focused
Windows checks**, with two POSIX-only skips. See its [source hashes, scopes and
raw results](validation/legacy-cleanup/report.md). These results describe that
snapshot. They do not validate subsequent code, documentation or packaging edits.
Hosted Windows/Linux/macOS acceptance and macOS execution remain unestablished
by the retained local results.

| Evidence | Scope |
|---|---|
| [Platform validation](platform-validation.md) | Reproduction commands and source-specific runtime reports |
| [Candidate status](release-candidate.md) | Publication requirements and current acceptance limits |
| [Proposal conformance](workforce-conformance.md) | Original requirements mapped to code/tests and remaining work |
| [Transition audit](transition-crash-audit.md) | Selected race/crash evidence and historical counterexamples |
| [Workforce trials](workforce-benchmark.md) | Scripted mechanics and mixed live-agent results; no productivity claim |
| [Documentation alignment](validation/markdown-alignment/report.md) | File inventory, link/command checks and focused installer/simulation evidence |
| [Generated simulation](simulation.md) | Scripted real-Git workflow, not a live-provider benchmark |

The browser dashboard is a newer **unreleased source feature** implemented in
`swarm_web.py` and included in the current manifest file list. It is outside the
recorded runtime snapshot. See [its scope](design.md#optional-browser-preview)
and [operation](web-dashboard.md); inclusion does not establish platform acceptance.

## Historical material

The [original proposal](../agents-collaboration-resilient-workforce-design.md)
records the starting design and acceptance targets. [CHANGELOG.md](../CHANGELOG.md)
records development and release history. Reports under `validation/` apply to
their own source hashes and runtimes; failed or incomplete attempts stay retained.
The implementation guide's verification history describes earlier stages, not
the current suite or a hosted CI pass.
