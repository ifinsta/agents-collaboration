# Web dashboard

This unreleased source feature is included in the current manifest file list.
Use a matching source installation; an older published tag may not contain it.
The [evidence index](README.md#evidence-and-release-readiness) distinguishes recorded
runtime snapshots from later dashboard changes.

```bash
swarm dashboard --web                  # prints the link and opens it in your browser
swarm dashboard --web --no-open        # print the link only
swarm dashboard --web --port 9000      # another port (default: the saved one, else 8787)
swarm dashboard --web --observe        # do not sweep; another `monitor` does
swarm dashboard --web --reset-link     # make a new link; old links stop working
swarm dashboard --web --read-only      # the page only shows; it cannot act as you
swarm steward                          # the inbox steward, reviewing every minute (--once for one review)
```

## One dashboard for every board

There is one dashboard per user, not one per run. It lives at a fixed address, `http://127.0.0.1:8787/` unless
that port is taken (then the next free one, which is saved and reused), and its link keeps the same token every
time. A bookmark of it keeps working across restarts.

- The first `swarm dashboard --web` starts it and stays in the foreground until Ctrl+C.
- Every later run, from any repository or session, **adds its board to the running dashboard**, prints the same
  link with that board selected, and returns at once. It does not start a second server.
- A board switcher appears in the top bar once more than one board is listed. The address carries the board
  (`?b=ID`), so a link opens the board it names.
- If the terminal that started it is closed, run the command again: it comes back at the same address with the
  same link.

The shared state is in `~/.agents/swarm-web/` (set `SWARM_WEB_HOME` to move it): `server.json` holds the port and
token, `boards/` one small file per board. Only the terminal that started the dashboard sweeps its own board;
other listed boards are only read, so run `swarm monitor` for them (or rely on their agents' own commands, which
sweep).

A link without its token, or with an old one, shows a short explanation instead of data.

The terminal board (`swarm dashboard`) is unchanged. This is the same board, drawn for a person who wants
more room: who is working on what, what needs a human, what the agents said to each other, and why a
task is where it is. It refreshes every three seconds and stops with Ctrl+C.

## Acting from the page

The page is a tool, not only a view. These actions run as **you** (the human), from the item they concern:

| Where | Action | What runs |
|---|---|---|
| Overview, Decisions | Answer or waive a question | `swarm answer` / `swarm waive` |
| Overview, Decisions | Approve an architecture brief (after a confirmation) | `swarm goal architecture GOAL --approve` |
| Inbox | Reply to a message, with its kind | `swarm send AGENT TEXT --kind KIND --reply-to ID` |
| Inbox | Acknowledge a message addressed to you | `swarm bus receive` then `swarm bus ack`, with its receipt |
| Team, Inbox | Review inboxes now | `swarm steward --once` |
| Team, steward inspector | Start an LLM reviewer (after a confirmation) | `swarm add INBOX-n ...` then `swarm spawn CLI --name NAME --task INBOX-n` |

Each action runs the real `swarm` command in that board's repository, so the engine's own checks, refusals and
events apply exactly as in a terminal; a refusal is shown under the button. Everything else (interrupts,
take-overs, incident decisions, dead letters) still shows the command to copy. A reply never acknowledges a
message, and you can acknowledge only messages addressed to you. While you type, the live refresh pauses so your
text is never redrawn away; drafts survive a refresh. `--read-only` turns all actions off and the top bar then
says "Read-only" instead of "Acting as you".

## The inbox steward

Coordination stalls when messages sit unread. The steward is a built-in participant (not an LLM, and it takes no
agent slot) that reviews every inbox:

- A message an agent has left unacknowledged for 10 minutes (`--remind-after-min`) gets one reminder to that agent,
  listing the message numbers and how to acknowledge them. It repeats only after three such periods.
- If the recipient is offline, the steward tells the coordinator (or you, without one) instead.
- A critical message left waiting is also escalated to the coordinator, before it becomes a dead letter.
- Dead letters are reported to you once.

It **never acknowledges a message for anyone**: a receipt must come from its recipient. Its reminders expire on
their own, so they do not pile up in the inboxes they are about, and the human's own inbox is left to the page.
Run it with `swarm steward` in a terminal or console pane, or press **Review inboxes now**. On the team canvas it
sits beside the orchestrator, with dotted lines to the agents it reminded.

For judgement calls (reading threads, drafting replies), start an **LLM reviewer** from the steward's inspector: it
creates a task `INBOX-n` ("Review every inbox: answer or escalate what is waiting, acknowledge what is addressed to
you") and spawns the CLI you pick on it. It uses that CLI's account and tokens, and works like any other agent:
one task, its own worktree, and its own acknowledgements.

## What it shows

The **Sessions** page adds a tab per owned execution, retained worker/supervisor
output, observed exit status and current task evidence. Its GET endpoints are
observational and board-scoped; start/stop controls use the existing CLI. For one
terminal with headless workers, use `swarm sessions` or `swarm console --managed`.
See [managed sessions](managed-sessions.md) for lifetime and capture limits.

| Page | Contents |
|---|---|
| Overview | A summary strip (agents online, tasks merged, waiting on you, blocked), a team table (status, task, step, contract clock, last seen), a work table, a "waiting on you" list (answer or waive a question, approve a brief, in place) and a plain-language activity log |
| Team | A canvas of the team in lanes (Governance, Orchestration, Execution, Assurance, Integration) with solid, dotted and dashed lines between agents, and an inspector for the selected one. See [the team canvas](#the-team-canvas) |
| Inbox | Every message with its kind, priority and acknowledgement state; filters for questions, decisions, warnings, reviews and dead letters; a thread view; per-recipient delivery, receipt lease and envelope fields |
| Decisions | Open questions, architecture briefs awaiting approval, contracts being negotiated with their decision window, incident reviews, interrupts, and what was recently settled |
| Tasks, Task | A table of every task, and per task: the plan as an ordered timeline with the evidence for each step, scope and locks, contract clock against its terms, checkpoints, the holder, open questions and the task's own events |

There is no free-form "debate" page. The tool has no such concept: disagreement is bounded and typed
(one contract counter, a timed decision window, evidence-backed incident reviews, decision messages), and
the Decisions page shows those.

## The team canvas

Agents are shown as `Alex (claude) – Orchestrator`: a display name, the CLI kind in brackets and a role.
The board stores a name and a kind, not a job title, so **roles are derived**, never configured:

| Role | Shown when |
|---|---|
| Owner | The human (the "You" node) |
| Orchestrator | The agent is the current coordinator |
| Implementer | Any other agent |
| Independent reviewer | The agent is assigned to review an open incident |
| Steward | The built-in inbox steward (always shown; "Not started" until it first runs) |

Each agent has an icon: a small line drawing of a bot (a different body for each kind of CLI, such as
`claude`, `opencode` or `codex`, and one picked consistently for kinds it does not know), with a badge for
its role. The icons are original drawings, not vendor logos.

The lines are facts read from the board, not decoration:

| Line | Meaning | Comes from |
|---|---|---|
| Solid arrow | Accountability: the human approves, the orchestrator assigns, an implementer submits to the integration gate | The coordinator, task holders, tasks in the merge queue |
| Dotted | Collaboration between peers: a review request, a shared lesson, or the number of messages; and the steward's reminders | Messages between two non-coordinator agents, and from the steward, in the last 24 hours |
| Dashed blue arrow | Independent review | An open incident, its reviewer and its subject |

The Show buttons hide a group of lines. A silent or offline agent is marked with a diamond and a red icon
(status is always a shape and a word, never colour alone), and its inspector offers the take-over command.

## Screen sizes

The page adapts from a phone to a wide monitor. It was measured in a browser at 390, 600, 820, 1024,
1280 and 1440 px wide with no horizontal page scroll at any of them, on every page.

- **Phone (up to 760 px).** The top bar becomes two rows with the tabs underneath. Tables turn into stacked
  rows that keep their column names. Touch targets are at least 44 px. In an inbox the open message comes
  first, then the list.
- **Tablet (up to 860 px for tables, 1000 px for the inbox).** Tables stack and the inbox puts the thread
  before the list.
- **Team page.** Wide screens show the canvas, which fits the available width and tightens its cards on
  tablets. A phone starts on **List**: the same lanes and cards in a single column, with each card spelling
  out its connections in words ("Assigned by Ann (claude)", "Reviewed by Mia (gemini)") and the inspector
  below. The Canvas and List buttons switch views on any screen.

## Security model

- Listens on `127.0.0.1` only. There is no option to bind another address.
- Every data request must carry the link's token (in the link, then a header) and a `Host` of
  `127.0.0.1:PORT` or `localhost:PORT`. These checks mitigate cross-site access and DNS rebinding. The token is
  random, kept in `~/.agents/swarm-web/server.json` and reused so the link is stable; `--reset-link` replaces it.
  The page itself carries no board data and loads without the token, so a missing token gets an explanation.
- The list of boards is a file a person can edit. The server serves only paths that are a real
  `.../swarm/swarm.db` and a board id of eight hex digits, and opens each read-only.
- On Windows the port is taken exclusively, so another program cannot share it.
- Views are `GET` requests that open the board with a read-only SQLite connection (`mode=ro`, `query_only`).
- Actions are one endpoint, `POST /api/act`, which needs the token header, an `Origin` that is the dashboard's
  own address, a JSON body of at most 16 KB and an action from a fixed list. Inputs are checked first (ids are
  numbers, names match the agent-name pattern, text is 1 to 4000 characters). The server then runs `swarm` with
  an argument list, never a shell, and puts free text after `--` so it can never be read as an option. It runs
  the `swarm.py` that registered the board (a `swarm.py` with `swarm_core.py` beside it), in that repository.
- **Anyone with the link can act as you** on the boards it lists. Keep the link private, use `--reset-link` if
  it was shared, and `--read-only` when you only want to watch.
- Board text is written by agents and is untrusted. The page builds its interface from text nodes only
  (never `innerHTML`), and its Content-Security-Policy is `default-src 'none'` with a single
  nonce-protected script and style, `connect-src 'self'` and no external fonts, scripts or images.
- Anyone with the link can read every listed board (messages, questions, notes), as any local process already
  can read `.git/swarm/`. Do not forward the link; use `--reset-link` if it has been shared. Stop the server
  when you are done.
- Unless `--observe` is given, the server runs the same sweep every `swarm` command runs (marking silent
  agents offline, expiring contracts, escalating unanswered critical messages) every few seconds, as the
  terminal dashboard does. These sweeps can update liveness and recovery records
  through the normal engine; use `--observe` for an observational server loop.

## Files and endpoints

`swarm_web.py` sits next to `swarm_core.py` and uses the standard library only. The page is one string in
that file. JSON endpoints, all `GET` and all requiring the token header: `/api/overview`,
`/api/inbox?tab=`, `/api/message/ID`, `/api/team`, `/api/decisions`, `/api/task/ID` (each takes `b=BOARD`),
`/api/boards`, `/api/ping`, `/api/sessions` and `/api/sessions/EXECUTION_ID`; and one `POST`, `/api/act`. They are
for the page; the supported machine interface remains `--json` (protocol v2).
